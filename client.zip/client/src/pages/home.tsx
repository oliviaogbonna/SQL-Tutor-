import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { tutorialSteps, TutorialStep } from "@/lib/tutorial-data";
import { CodeViewer } from "@/components/CodeViewer";
import { ConsoleOutput } from "@/components/ConsoleOutput";
import { Play, ChevronRight, Database, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

export default function Home() {
  const [location, setLocation] = useLocation();
  const [activeStepId, setActiveStepId] = useState<string>("connect");
  const [isOutputVisible, setIsOutputVisible] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Sync state with URL hash or default
  useEffect(() => {
    const hash = window.location.hash.replace("#", "");
    if (hash && tutorialSteps.find(s => s.id === hash)) {
      setActiveStepId(hash);
    } else {
      setActiveStepId("connect");
    }
    setIsOutputVisible(false);
  }, [location]); // Re-run when location changes (although hash changes don't always trigger this in wouter, manual handling is safer)

  const activeStep = tutorialSteps.find((s) => s.id === activeStepId) || tutorialSteps[0];

  const handleStepChange = (id: string) => {
    setActiveStepId(id);
    window.location.hash = id;
    setIsOutputVisible(false);
    setIsMobileMenuOpen(false);
  };

  const handleRun = () => {
    setIsOutputVisible(false);
    setTimeout(() => setIsOutputVisible(true), 100); // Small delay to reset animation
  };

  const SidebarContent = () => (
    <div className="h-full flex flex-col bg-sidebar border-r border-sidebar-border">
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center space-x-2 text-primary">
          <Database className="w-6 h-6" />
          <h1 className="font-bold text-lg tracking-tight text-sidebar-foreground">MySQL Tutor</h1>
        </div>
        <p className="text-xs text-muted-foreground mt-2">Interactive Python + MySQL Guide</p>
      </div>
      <ScrollArea className="flex-1 py-4">
        <div className="space-y-1 px-3">
          {tutorialSteps.map((step, index) => (
            <button
              key={step.id}
              onClick={() => handleStepChange(step.id)}
              className={cn(
                "w-full flex items-center space-x-3 px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-200 group",
                activeStepId === step.id
                  ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm"
                  : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
              )}
            >
              <div className={cn(
                "flex items-center justify-center w-6 h-6 rounded border transition-colors",
                activeStepId === step.id 
                  ? "border-primary/30 bg-primary/10 text-primary" 
                  : "border-transparent text-muted-foreground/70 group-hover:text-foreground"
              )}>
                <step.icon className="w-3.5 h-3.5" />
              </div>
              <span>{step.title}</span>
              {activeStepId === step.id && (
                <motion.div
                  layoutId="activeIndicator"
                  className="ml-auto w-1.5 h-1.5 rounded-full bg-primary"
                />
              )}
            </button>
          ))}
        </div>
      </ScrollArea>
      <div className="p-4 border-t border-sidebar-border">
        <div className="text-xs text-muted-foreground text-center">
          Based on W3Schools Python/MySQL
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Desktop Sidebar */}
      <div className="hidden md:block w-64 flex-shrink-0">
        <SidebarContent />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between p-4 border-b border-border bg-sidebar/50 backdrop-blur-sm">
           <div className="flex items-center space-x-2 text-primary">
            <Database className="w-5 h-5" />
            <span className="font-bold">MySQL Tutor</span>
          </div>
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-72 bg-sidebar border-r-sidebar-border">
              <SidebarContent />
            </SheetContent>
          </Sheet>
        </div>

        <ScrollArea className="flex-1">
          <div className="max-w-5xl mx-auto p-6 md:p-8 lg:p-12 space-y-8">
            {/* Header */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-sm text-primary font-medium uppercase tracking-wider">
                <span className="px-2 py-0.5 rounded-full bg-primary/10 border border-primary/20">Step {tutorialSteps.findIndex(s => s.id === activeStepId) + 1}</span>
                <span>/</span>
                <span>{tutorialSteps.length}</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-white">{activeStep.title}</h2>
              <p className="text-lg text-muted-foreground max-w-2xl leading-relaxed">
                {activeStep.description}
              </p>
            </div>

            {/* Main Grid */}
            <div className="grid lg:grid-cols-2 gap-6 lg:gap-8">
              {/* Left Column: Code */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium text-white/60 uppercase tracking-widest">Source Code</h3>
                  <Button 
                    onClick={handleRun}
                    size="sm" 
                    className={cn(
                      "transition-all duration-300",
                      isOutputVisible 
                        ? "bg-green-500/10 text-green-400 hover:bg-green-500/20 border-green-500/50" 
                        : "bg-primary text-primary-foreground hover:bg-primary/90"
                    )}
                  >
                    <Play className="w-3.5 h-3.5 mr-2 fill-current" />
                    {isOutputVisible ? "Run Again" : "Run Code"}
                  </Button>
                </div>
                
                <CodeViewer code={activeStep.code} />
                
                <div className="bg-card/50 border border-white/5 rounded-lg p-4 text-sm text-muted-foreground">
                  <h4 className="text-white/80 font-medium mb-2 flex items-center">
                    <span className="w-1 h-4 bg-primary rounded-full mr-2" />
                    Explanation
                  </h4>
                  {activeStep.explanation}
                </div>
              </div>

              {/* Right Column: Output */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-white/60 uppercase tracking-widest">Terminal Output</h3>
                <div className="h-[400px] bg-black/80 rounded-lg border border-white/10 p-6 shadow-inner relative overflow-hidden">
                   {/* Scanline effect */}
                   <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-10 pointer-events-none bg-[length:100%_4px,3px_100%] opacity-20" />
                   
                   <ConsoleOutput 
                     output={activeStep.output} 
                     isVisible={isOutputVisible} 
                   />
                </div>
              </div>
            </div>

            {/* Navigation Footer */}
            <div className="flex justify-between pt-8 border-t border-white/5">
               <Button
                 variant="ghost"
                 disabled={tutorialSteps.findIndex(s => s.id === activeStepId) === 0}
                 onClick={() => handleStepChange(tutorialSteps[tutorialSteps.findIndex(s => s.id === activeStepId) - 1].id)}
                 className="text-muted-foreground hover:text-white"
               >
                 Previous Step
               </Button>

               <Button
                 disabled={tutorialSteps.findIndex(s => s.id === activeStepId) === tutorialSteps.length - 1}
                 onClick={() => handleStepChange(tutorialSteps[tutorialSteps.findIndex(s => s.id === activeStepId) + 1].id)}
                 className="group"
               >
                 Next Lesson
                 <ChevronRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
               </Button>
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
