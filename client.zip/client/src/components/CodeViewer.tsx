import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Copy, Check } from "lucide-react";
import { useState } from "react";

interface CodeViewerProps {
  code: string;
  language?: string;
}

export function CodeViewer({ code }: CodeViewerProps) {
  const lines = code.split("\n");
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="font-mono text-sm bg-[#1e1e1e] rounded-lg border border-white/10 overflow-hidden shadow-xl group">
      <div className="flex items-center justify-between px-4 py-2 bg-[#252526] border-b border-white/5">
        <div className="flex space-x-2">
          <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50" />
          <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50" />
          <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50" />
        </div>
        <div className="flex items-center space-x-3">
            <span className="text-xs text-white/40 font-medium">main.py</span>
            <button 
                onClick={handleCopy}
                className="text-white/40 hover:text-white transition-colors"
                title="Copy code"
            >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
        </div>
      </div>
      <div className="p-4 overflow-x-auto">
        <pre className="font-mono text-[13px] leading-6">
          {lines.map((line, i) => (
            <div key={i} className="table-row">
              <span className="table-cell select-none text-right pr-4 text-white/20 w-8">
                {i + 1}
              </span>
              <span className="table-cell whitespace-pre text-gray-300">
                {highlightPython(line)}
              </span>
            </div>
          ))}
        </pre>
      </div>
    </div>
  );
}

// Simple regex-based highlighter for Python
function highlightPython(line: string) {
  // Comments
  if (line.trim().startsWith("#")) {
    return <span className="text-green-600/80 italic">{line}</span>;
  }

  const parts = line.split(/(".*?"|'.*?'|\bdef\b|\bclass\b|\bimport\b|\bfrom\b|\breturn\b|\bif\b|\belse\b|\bfor\b|\bin\b|\bprint\b|\bTrue\b|\bFalse\b|\bNone\b)/g);

  return parts.map((part, index) => {
    if (part.startsWith('"') || part.startsWith("'")) {
      return <span key={index} className="text-orange-400">{part}</span>;
    }
    if (["def", "class", "import", "from", "return", "if", "else", "for", "in", "True", "False", "None"].includes(part)) {
      return <span key={index} className="text-blue-400">{part}</span>;
    }
    if (part === "print") {
      return <span key={index} className="text-yellow-300">{part}</span>;
    }
    return part;
  });
}
