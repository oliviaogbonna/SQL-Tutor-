import { motion } from "framer-motion";
import { Terminal } from "lucide-react";

interface ConsoleOutputProps {
  output: string;
  isVisible: boolean;
}

export function ConsoleOutput({ output, isVisible }: ConsoleOutputProps) {
  if (!isVisible) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-white/20 space-y-4">
        <Terminal className="w-12 h-12 opacity-20" />
        <p className="text-sm font-mono">Click "Run Code" to execute</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="font-mono text-sm"
    >
      <div className="mb-2 text-green-400 text-xs">user@replit:~/project$ python main.py</div>
      <div className="whitespace-pre-wrap text-white/90 leading-relaxed">
        {output}
      </div>
      <motion.div
        animate={{ opacity: [1, 0] }}
        transition={{ repeat: Infinity, duration: 0.8 }}
        className="inline-block w-2 h-4 bg-white/50 ml-1 align-middle"
      />
    </motion.div>
  );
}
