import { Terminal, Database, Table, Plus, Search, Trash, RefreshCw, Layers } from "lucide-react";

export interface TutorialStep {
  id: string;
  title: string;
  icon: any;
  description: string;
  code: string;
  output: string;
  explanation: string;
}

export const tutorialSteps: TutorialStep[] = [
  {
    id: "connect",
    title: "Connect to Database",
    icon: Terminal,
    description: "Establish a connection to the MySQL server.",
    code: `import mysql.connector

# Connect to MySQL server
mydb = mysql.connector.connect(
  host="localhost",
  user="yourusername",
  password="yourpassword"
)

print(mydb)
`,
    output: `<mysql.connector.connection.MySQLConnection object at 0x00000188863E8630>`,
    explanation: "This establishes the initial connection to the MySQL server instance running on localhost."
  },
  {
    id: "create-db",
    title: "Create Database",
    icon: Database,
    description: "Create a new database named 'mydatabase'.",
    code: `# Create a Database named mydatabase
mycursor = mydb.cursor()
mycursor.execute("CREATE DATABASE mydatabase")

print("Database 'mydatabase' created successfully.")`,
    output: `Database 'mydatabase' created successfully.`,
    explanation: "We use a cursor object to execute SQL commands. Here we run the 'CREATE DATABASE' SQL command."
  },
  {
    id: "create-table",
    title: "Create Table",
    icon: Table,
    description: "Create a 'Customers' table with columns.",
    code: `# Connect to the created database
mydb = mysql.connector.connect(
  host="localhost",
  user="yourusername",
  password="yourpassword",
  database="mydatabase"
)
mycursor = mydb.cursor()

# Create a Table within mydatabase named Customers
mycursor.execute("CREATE TABLE Customers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), address VARCHAR(255))")

print("Table 'Customers' created.")`,
    output: `Table 'Customers' created.`,
    explanation: "We reconnect specifying the database, then create a table with an auto-incrementing primary key."
  },
  {
    id: "insert",
    title: "Insert Data",
    icon: Plus,
    description: "Insert a new record into the Customers table.",
    code: `# Insert data in the Customers table
sql = "INSERT INTO Customers (name, address) VALUES (%s, %s)"
val = ("John", "Highway 21")

mycursor.execute(sql, val)
mydb.commit()

print(mycursor.rowcount, "record inserted.")`,
    output: `1 record inserted.`,
    explanation: "We use parameterized queries (%s) to prevent SQL injection. 'commit()' is required to save changes."
  },
  {
    id: "select",
    title: "Select Records",
    icon: Search,
    description: "Retrieve and display all records.",
    code: `# Select all records from the Customers table
mycursor.execute("SELECT * FROM Customers")
result = mycursor.fetchall()

for x in result:
  print(x)`,
    output: `(1, 'John', 'Highway 21')`,
    explanation: "fetchall() retrieves all rows from the last executed statement."
  },
  {
    id: "sort",
    title: "Sort Records",
    icon: RefreshCw,
    description: "Order results by name.",
    code: `# Sort by name Ascending
mycursor.execute("SELECT * FROM Customers ORDER BY name ASC")
result = mycursor.fetchall()
for x in result:
  print(x)

# Sort by name Descending
mycursor.execute("SELECT * FROM Customers ORDER BY name DESC")
result = mycursor.fetchall()
for x in result:
  print(x)`,
    output: `--- Ascending ---
(1, 'John', 'Highway 21')
(2, 'Amy', 'Apple st 652')

--- Descending ---
(2, 'Amy', 'Apple st 652')
(1, 'John', 'Highway 21')`,
    explanation: "Use ORDER BY to sort results. ASC for ascending (default) and DESC for descending."
  },
  {
    id: "update",
    title: "Update Records",
    icon: RefreshCw,
    description: "Modify existing data in the table.",
    code: `# Update existing records
sql = "UPDATE Customers SET address = 'Mountain 21' WHERE address = 'Highway 21'"

mycursor.execute(sql)
mydb.commit()

print(mycursor.rowcount, "record(s) affected")`,
    output: `1 record(s) affected`,
    explanation: "UPDATE allows modifying existing rows. Always use a WHERE clause to specify which rows to update."
  },
  {
    id: "delete",
    title: "Delete Records",
    icon: Trash,
    description: "Remove specific records from the table.",
    code: `# Delete a record
sql = "DELETE FROM Customers WHERE name = 'John'"

mycursor.execute(sql)
mydb.commit()

print(mycursor.rowcount, "record(s) deleted")`,
    output: `1 record(s) deleted`,
    explanation: "DELETE removes rows. Be careful to include a WHERE clause, or all records will be deleted!"
  },
  {
    id: "join",
    title: "Join Tables",
    icon: Layers,
    description: "Combine rows from two or more tables.",
    code: `# Join Customers and Orders tables
sql = "SELECT Customers.name, Orders.product FROM Customers INNER JOIN Orders ON Customers.id = Orders.customer_id"

mycursor.execute(sql)
result = mycursor.fetchall()

for x in result:
  print(x)`,
    output: `('John', 'Laptop')
('Amy', 'Phone')`,
    explanation: "INNER JOIN selects records that have matching values in both tables."
  }
];
